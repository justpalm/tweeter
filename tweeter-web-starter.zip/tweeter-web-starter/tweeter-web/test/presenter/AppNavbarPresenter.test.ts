import { AuthToken } from "tweeter-shared";
import { AppNavbarPresenter, AppNavbarView } from "../../src/presenter/AppNavbarPresenter";
import { anything, capture, instance, mock, spy, verify, when} from "@typestrong/ts-mockito";
import { beforeEach, describe, expect, it } from "@jest/globals";
import { UserService } from "../../src/model.service/UserService";


describe ("AppNavbarPresenter" , () => {
    
    let mockAppNavbarPresenterView : AppNavbarView;
    let appNavbarPresenter: AppNavbarPresenter;
    let mockService : UserService
    
    const authToken = new AuthToken("abc123", Date.now());
    
    
    beforeEach(() => {
        mockAppNavbarPresenterView = mock<AppNavbarView>();
        const mockApppNavbarPresenterViewInstance = instance(mockAppNavbarPresenterView);

        const appNavbarPresenterSpy = spy(new AppNavbarPresenter(mockApppNavbarPresenterViewInstance));
        appNavbarPresenter = instance(appNavbarPresenterSpy);

        mockService = mock<UserService>()   
        when(appNavbarPresenterSpy.service).thenReturn(instance(mockService));

    })

    it("tells the view to display a logging out message", async () =>{
        await appNavbarPresenter.logOut(authToken)
        verify(mockAppNavbarPresenterView.displayInfoMessage("Logging Out...", 0)).once();
    })


    it("calls the logout on the user service with the correct auth token", async() => {
        await appNavbarPresenter.logOut(authToken);
        verify(mockService.logout(authToken)).once();

        let [capturedAuthToken] = capture(mockService.logout).last();
        expect(capturedAuthToken).toEqual(authToken)

    })

    it ("tells the view to clear the info message that was displayed previosuly, clears the user info, and navigates to the login page when successful", async() => {
        await appNavbarPresenter.logOut(authToken);

        verify(mockAppNavbarPresenterView.deleteMessage(anything())).once();
        verify(mockAppNavbarPresenterView.clearUserInfo()).once();
        verify(mockAppNavbarPresenterView.navigate("/login")).once();         
    } )

    it ("tells the view to display an error message and does not tell it to clear the info message, clear the user info, or navigate to the login page when unsuccessful", async () => {
        let error = new Error("An error occurred");
        when(mockService.logout(anything())).thenThrow(error);

        await appNavbarPresenter.logOut(authToken);

        let [errorString] = capture(mockAppNavbarPresenterView.displayErrorMessage).last();
        verify(mockAppNavbarPresenterView.displayErrorMessage("Failed to log user out because of exception: An error occurred")).once();
    })

});


