import { useContext } from "react"
import { ToastActionsContext, ToastListContext } from "./ToastContexts"
import { ToastType } from "./Toast"

interface MessageActions {
  displayInfoMessage: (
    message: string,
    duration: number,
    bootstrapClasses?: string
  ) => string;
  displayErrorMessage: (
    message: string,
    bootstrapClasses?: string
  ) => string;
  deleteMessage: (messageId: string) => void;
  deleteAllMessages: () => void;
}

export const useMessageActions = (): MessageActions => {
    const {displayToast, deleteToast, deleteAllToasts} = useContext(ToastActionsContext)
   
    return {
        displayInfoMessage: (message :string , duration : number , bootstrapClasses? : string) => displayToast(ToastType.Info, message, duration, undefined, bootstrapClasses),
        displayErrorMessage: (message :string, bootstrapClasses? : string) => displayToast(ToastType.Error, message, 0, bootstrapClasses),
        deleteMessage: (messageId: string) => deleteToast(messageId),
        deleteAllMessages: () => deleteAllToasts(),
    };
}  //All hooks are use.... by the way!  // Hooks typcially return an object


export const useMessageList = () => {
    return useContext(ToastListContext)

}