// AI-assisted: see AI-ATTRIBUTION.md
import type { TweeterRequest, TweeterResponse } from "tweeter-shared";

export class ClientCommunicator {
  private SERVER_URL: string;

  public constructor(SERVER_URL: string) {
    this.SERVER_URL = SERVER_URL;
  }

  public async doPost<REQ extends TweeterRequest, RES extends TweeterResponse>(
    req: REQ | undefined,
    endpoint: string,
    headers?: Headers,
  ): Promise<RES> {
    if (headers && req) {
      headers.append("Content-type", "application/json");
    } else if (req) {
      headers = new Headers({
        "Content-type": "application/json",
      });
    }

    const url = this.getUrl(endpoint);
    const params = this.getParams(
      "POST",
      headers,
      req ? JSON.stringify(req) : req,
    );

    try {
      const resp: Response = await fetch(url, params);
      if (resp.ok) {
        const response: RES = await resp.json();
        return response;
      } else {
        const error: { error?: string; errorMessage?: string } =
          await resp.json();
        throw new Error(
          error.error ?? error.errorMessage ?? `HTTP ${resp.status}`,
        );
      }
    } catch (error) {
      console.error(error);
      throw new Error(
        `Client communicator ${params.method} failed:\n${
          (error as Error).message
        }`,
      );
    }
  }

  private getUrl(endpoint: string): string {
    return this.SERVER_URL + endpoint;
  }

  private getParams(
    method: string,
    headers?: Headers,
    body?: BodyInit,
  ): RequestInit {
    const params: RequestInit = { method: method };
    if (headers) {
      params.headers = headers;
    }
    if (body) {
      params.body = body;
    }
    return params;
  }
}
